using System;
using System.Collections.Generic;

namespace SuperBackendNR85IA.Calculations
{
    public static class TelemetryCalculations
    {
        public static double GetSessionTime(double? sessionTime) => sessionTime ?? 0;

        public static double GetFuelLapsLeft(double fuelLevel, double fuelUsePerLap) =>
            fuelUsePerLap > 0 ? fuelLevel / fuelUsePerLap : 0;

        public static bool GetFuelWarning(double fuelLevel, double fuelUsePerLap) =>
            GetFuelLapsLeft(fuelLevel, fuelUsePerLap) < 2;

        public static double GetFuelForTargetLaps(int laps, double fuelUsePerLap) =>
            laps * fuelUsePerLap;

        public static double GetFuelEfficiency(double lapDistTotal, double fuelUsedTotal) =>
            fuelUsedTotal > 0 ? lapDistTotal / fuelUsedTotal : 0;

        // Método adicionado para calcular o consumo de combustível por volta
        public static float CalculateFuelPerLap(
            float totalFuelUsedInSession,
            float currentLapDistPct,
            float lapLastLapTime, // Pode ser usado para lógica mais avançada, como confirmar conclusão de volta
            int currentLapNumber,
            float sdkReportedFuelPerLap)
        {
            // Se estiver muito no início da sessão (ex: primeira volta incompleta),
            // pode ser mais confiável usar a estimativa do SDK, se válida.
            if (currentLapNumber <= 1 && currentLapDistPct < 0.90f) // Menos de 90% da primeira volta
            {
                // Retorna a estimativa do SDK se for positiva, senão 0.
                return sdkReportedFuelPerLap > 0 ? sdkReportedFuelPerLap : 0f;
            }

            // Calcula o número "efetivo" de voltas completadas para o consumo.
            // Ex: Se está na volta 2 (currentLapNumber=2) e completou 50% (currentLapDistPct=0.5),
            // então completou 1 volta inteira + 0.5 da atual = 1.5 voltas efetivas.
            float effectiveLapsCompleted = (currentLapNumber - 1) + currentLapDistPct;

            if (effectiveLapsCompleted > 0.1f && totalFuelUsedInSession > 0.01f) // Evita divisão por zero e usa dados significativos
            {
                float calculatedAverageFuelPerLap = totalFuelUsedInSession / effectiveLapsCompleted;
                if (calculatedAverageFuelPerLap > 0)
                {
                    return calculatedAverageFuelPerLap;
                }
            }

            // Como fallback, se o cálculo não for positivo ou os dados não forem suficientes,
            // retorna a estimativa do SDK (se válida) ou 0.
            return sdkReportedFuelPerLap > 0 ? sdkReportedFuelPerLap : 0f;
        }

        public static Dictionary<string, double> GetTireWear(double? fl, double? fr, double? rl, double? rr) => new()
        {
            {"FL", 100 - (fl ?? 0)},
            {"FR", 100 - (fr ?? 0)},
            {"RL", 100 - (rl ?? 0)},
            {"RR", 100 - (rr ?? 0)}
        };

        public static Dictionary<string, double[]> GetTireTemps(double[] fl, double[] fr, double[] rl, double[] rr) => new()
        {
            // Corrigido para tratar arrays nulos de forma mais segura se GetSdkArray retornar nulo antes de virar empty
            {"FL", fl ?? Array.Empty<double>()}, // Ou new double[] { 0, 0, 0 } se preferir um tamanho fixo
            {"FR", fr ?? Array.Empty<double>()},
            {"RL", rl ?? Array.Empty<double>()},
            {"RR", rr ?? Array.Empty<double>()}
        };

        public static Dictionary<string, double> GetDeltaTimes(double? current, double? last, double? best) => new()
        {
            {"Current", current ?? 0},
            {"Last", last ?? 0},
            {"Best", best ?? 0}
        };

        public static List<object> GetRelativeData(List<object> relativeCars) =>
            relativeCars ?? new List<object>();

        public static List<object> GetStandings(List<object> standings) =>
            standings ?? new List<object>();
    }
}